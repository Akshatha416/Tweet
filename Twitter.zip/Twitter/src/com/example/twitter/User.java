package com.example.twitter;

import java.util.Scanner;

public class User {

	public static void main(String[] args) {

		
		try(Scanner sc=new Scanner(System.in)){
			System.out.println("Enter user name");
			String user=sc.nextLine();
			System.out.println("Enter password");
			String password=sc.nextLine();
			if("abcd".equals(user) && "1234".equals(password)) {
				System.out.println("Valid user");
				//swith
				}
			else
			{
				System.out.println("invalid username and password");
	
			}
	}
	}
}


