package com.example.twitService;

import java.io.IOException;
import java.sql.ResultSet;

import com.example.model.Login;

public interface TwitterService {
	public Login registration();
	
	public  void login() throws IOException;

	//public int postTweet(Login l1) throws IOException;

	public int viewMyTweets(Login l1);
	
	


	public int viewAllTweets();
    public int viewAllUser();
    public int resetPassword();
     public int logout();
    
    public int forgotPassword();

	int postTweet(ResultSet rs) throws IOException;
	

	
}
