package com.example.twitService;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.Scanner;

import com.example.model.Login;
import com.example.tweetf.Menu;

public class TwitterServiceImp implements TwitterService{
	
	 Menu m=new Menu();
	
     public static final String query1="insert into login(first_name,email,password) values(?,?,?)";
     public static final String query ="select * from login where email=? AND password=? ";
     public static final String query4="insert into tweet2(email,first_name,post,date,status) values(?,?,?,?,'Login')";

     
     
     Login l=new Login();
     
	@Override
	public Login registration() {
		 
		
		try( 
				Connection con=DriverManager.getConnection(m.db_url, m.user, m.pass);
				PreparedStatement ps=con.prepareStatement(query1);){
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter user name:");
			String name=sc.next();
			System.out.println("Enter Email:");
			String email=sc.next();
			System.out.println("Enter Password:");
			String password=sc.next();
			ps.setString(1, name);
			ps.setString(2, email);
			ps.setString(3, password);
			ps.executeUpdate();
			l.setFirst_name(name);
			l.setEmail(email);
			l.setPassword(password);
			System.out.println("Registered Successfully:");
			
		} catch(SQLException e) {e.printStackTrace();}
		return l;
	
	}
	

	@Override
	public   void login() throws IOException {
		
//		 System.out.println("Enter 1 for-->Post a Tweet \n Enter 2 for --> View My Tweets \n Enter 3 for--> View All Tweets\n Enter 4 for--> View All Users \n Enter 5 for-->ResetPassword  \n Enter 6 for--> Logout \n");
//		  
//		  System.out.println();
//		  Scanner scc=new Scanner(System.in);
//		  int c=scc.nextInt();
		 
		try( 
				Connection con=DriverManager.getConnection(m.db_url, m.user, m.pass);
				PreparedStatement ps=con.prepareStatement(query);){
			
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter Email_Id:");
			String emailid=sc.next();
			System.out.println("Enter Name:");
			String name=sc.next();
			//boolean s;
			
			
			ps.setString(1, emailid);
			
			System.out.println("Enter password:");
			String password=sc.next();
			ps.setString(2, password);
			
			 ResultSet rs=ps.executeQuery();
			
			while(rs.next())
				
			 {//s=true;
				System.out.println(" Successfully Login");
				
				l.setEmail(emailid);
				l.setPassword(password);
				l.setFirst_name(name);
				 System.out.println("Enter 1 for-->Post a Tweet \n Enter 2 for --> View My Tweets \n Enter 3 for--> View All Tweets\n Enter 4 for--> View All Users \n Enter 5 for-->ResetPassword  \n Enter 6 for--> Logout \n");
				  
				Scanner c1=new Scanner(System.in);
				int c=c1.nextInt();
				switch(c) {
			 case 1:


					//public static final String query4="insert into tweet2(email,first_name,post,date,status) values(?,?,?,?,'Login')";
				 
			// public int postTweet( rs)  {
					System.out.println("post a New tweet:");
					
					try(Connection conn2 = DriverManager.getConnection(m.db_url,m.user,m.pass);
							PreparedStatement ps2= conn2.prepareStatement(query4);)
					{
						
						
					
					System.out.println(rs.getString("email"));
				    
					//String emailp=rs.getEmail();
						//while(rs.next()) {
						String emailp=rs.getString("email");
						
						String fnamep=rs.getString("first_name");
						
						System.out.println("ENTER A POST:");

						BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
						
						String post=br.readLine();
						
						
				
						LocalDateTime date= LocalDateTime.now();
						
				        ps2.setString(1, emailp);
				 		ps2.setString(2, fnamep);
						ps2.setString(3, post);
						ps2.setString(4,date.toString());
						
						
						
						ps2.executeUpdate();//}
						System.out.println("Inserted post successfully:");
						

						
					}
							
					catch(SQLException e) {
						e.printStackTrace();
						
					}
			 //login();
			 break;
			 case 2:System.out.println("eee");
				}}}

			
		
		catch(SQLException e) {e.printStackTrace();}
		
		
		 System.out.println("Enter 1 for-->Post a Tweet \n Enter 2 for --> View My Tweets \n Enter 3 for--> View All Tweets\n Enter 4 for--> View All Users \n Enter 5 for-->ResetPassword  \n Enter 6 for--> Logout \n");
		  
		  System.out.println();
		  Scanner scc=new Scanner(System.in);
		  int c=scc.nextInt();
		 switch(c)
		  {
		  case 1:
			  System.out.println("tweet");
			  //POST a TWEET
			 // int ie1=postTweet();
			 // postTweet();
			 // ts.login();
//			  
//			  if(ie1==1) {viewAllTweets();}
//			  else if (ie1==2) {viewAllUser();}
//			  else if(ie1==3) {logout();}
//			  else if(ie1==4) {resetPassword();}
//			  else {System.out.println("Enter correct choice:");}
			//  i=1;
		 // break;
			 
		  case 2:
			  //VIEW MY TWEETS
			  int iv=viewMyTweets(l);
			 // if(iv==1) {postTweet();}
			   if(iv==2) {viewAllTweets();}
			  else if(iv==3) {viewAllUser();}
			  else if(iv==4) {resetPassword();}
			  else if(iv==5) { logout();}
			  else System.out.println("enter correct choice");
			  //ts.login();
			  //break;
		  case 3:
			  //VIEW All TWEETS
			  
			 int a=viewAllTweets();
			 login();
			 
			 if(a==1) { login();}
			 
			 else if(a==2) {resetPassword();}
			 else if(a==3) {  logout();}
			 else if(a==4) {viewAllUser();}
			else System.out.println("enter correct choice");
			  //i =1;
			 // break;
			 
			  
		  case 4:
			  
			  int b=viewAllUser();
			  if(b==1) {resetPassword();}
				 
				 else if(b==2)  logout();
				 //else if(b==3)postTweet(rs);
				 else if(b==4) viewAllTweets();
				 else System.out.println("enter correct choice");
			  //ts.login();
			  break;
		  case 5:
			 int cd= resetPassword();
			 if(cd==1) { login();}
			 System.out.println("Post");
             // postTweet(l);}
			// else if (cd==2) {postTweet(l);}
			// else System.out.println("enter correct choice");
			 
			 // break;
		  case 6:
			logout(); 
		  }
		
	}

	//@Override
//	public int postTweet(ResultSet rs) throws IOException {
//		System.out.println("post a New tweet:");
//		
//		try(Connection conn2 = DriverManager.getConnection(m.db_url,m.user,m.pass);
//				PreparedStatement ps= conn2.prepareStatement(query4);)
//		{
//			
//			
//		
//		System.out.println(rs.getString("email"));
//	    
//		//String emailp=rs.getEmail();
//			while(rs.next()) {
//			String emailp=rs.getString("email");
//			
//			String fnamep=rs.getString("first_name");
//			
//			System.out.println("ENTER A POST:");
//
//			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
//			
//			String post=br.readLine();
//			
//			
//	
//			LocalDateTime date= LocalDateTime.now();
//			
//	        ps.setString(1, emailp);
//	 		ps.setString(2, fnamep);
//			ps.setString(3, post);
//			ps.setString(4,date.toString());
//			
//			
//			
//			ps.executeUpdate();}
//			System.out.println("Inserted post successfully:");
//			
//
//			
//		}
//				
//		catch(SQLException e) {
//			e.printStackTrace();
//			
//		}
//		System.out.println("Enter the choice");
//	     System.out.println(" 1 For --> view all Post\n 2 For --> view all user \n 3 For--> logout \n 4 For ResetPassword");
//	     Scanner ie=new Scanner(System.in);
//	     int ie1=ie.nextInt();
//		return ie1;
//		
//		
//	}
	
	

public static final String query3="select * from tweet2 where first_name=?";
	@Override
	public int viewMyTweets(Login l1) {
		//System.out.println("VIEW MY TWEETS");
		try(Connection con=DriverManager.getConnection(m.db_url,m.user,m.pass);
				
				PreparedStatement ps6=con.prepareStatement(query3);
				)
		{
			
			String name6=l1.getFirst_name();
			ps6.setString(1, name6);
			ResultSet rs6=ps6.executeQuery();
			System.out.println("----------------------------------------");
			System.out.println("     Information about ur Posts          ");
			System.out.println("----------------------------------------");
			System.out.println(" Post                              DateAndTime  ");
			
			while(rs6.next()) {
				
				//System.out.println("name:"+rs6.getString("first_name"));
				System.out.println(rs6.getString("post")+"                     "+ rs6.getString("date"));
				
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
			}
		System.out.println("---------------------------------------------------------");
		
		System.out.println("Enter choice: 1 For-->'Post a Tweet' \n 2 For--> 'View All Tweets' \n 3 For--> 'view All Users' \n 4 For-->'ResetPassword' \n 5 For--> 'Logout' ");
		Scanner scm = new Scanner(System.in);
		int c=scm.nextInt();
		return c;	
	}

	static final String query5="select * from tweet2";
	@Override
	public int viewAllTweets() {
		System.out.println("          view All Posts          ");
		System.out.println("-------------------------------------------");
		System.out.println(" username       posts             Date-Time ");
		System.out.println("-------------------------------------------");
		System.out.println();
		
		try(Connection connt=DriverManager.getConnection(m.db_url,m.user,m.pass);
				Statement stt= connt.createStatement();
				ResultSet rst=stt.executeQuery(query5);){
			
			while(rst.next()) {
				
				System.out.println(rst.getString("first_name")+"          "+rst.getString("post")+"             "+rst.getString("date"));
				
				}
			}
				
catch(SQLException e) {
	e.printStackTrace();
}
	System.out.println();
//	System.out.println("Enter \n 1 for--> post a new Tweet \n 2 For--> ResetPassword \n 3 For--> Logout \n 4 for--> view All users");
//	
//	Scanner sc=new Scanner(System.in);
//	int a=sc.nextInt();
//	return a;
	
	return 1;
		
		
	}

public static final String queryu="select first_name from tweet2";
	@Override
	public int viewAllUser() {
		try(Connection connt=DriverManager.getConnection(m.db_url,m.user,m.pass);
				Statement stt= connt.createStatement();
				ResultSet rst=stt.executeQuery(queryu);){
			
			
			System.out.println("******************");
			System.out.println("   ALL Users  ");
			System.out.println("******************");
			while(rst.next()) {
				
				System.out.println(rst.getString("first_name"));
				
				}
			}
				
catch(SQLException e) {
	e.printStackTrace();
}
	System.out.println("Enter \n 1 for-->Reset Password \n 2 For--> Logout \n 3 For--> post a tweet \n 4 for view All Post ");	
	System.out.println();
	Scanner sc=new Scanner(System.in);
	int b=sc.nextInt();
	return b;
		
	}

	static final String query2="update login set password=? where password=?";
	@Override
	public int resetPassword() {
		try(Connection connr=DriverManager.getConnection(m.db_url,m.user,m.pass);
				PreparedStatement psr=connr.prepareStatement(query2);
				){
			
			Scanner sc3n = new Scanner(System.in);
			
			
			System.out.println("Enter OLD PASSWORD:");
			String oldpwd=sc3n.next();
			System.out.println("Enter New PASSWORD ");
			String newpwd=sc3n.next();
			psr.setString(1, newpwd);
			//psr.setString(1, newpwd);
			psr.setString(2, oldpwd);
			psr.executeUpdate();
			System.out.println("Successfully Set New Password:");
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		
		System.out.println("Enter 1 for-->Login  \n 2 for --> Logout");
		Scanner sc=new Scanner(System.in);
		int c=sc.nextInt();
		return c;
		
		
	}

	static final String queryf="update login set password=? where email=?";
	static final String query8="update tweet2 set status='login'";
	@Override
	public int forgotPassword() {
		System.out.println("Forgot Password");
		try(Connection conn=DriverManager.getConnection(m.db_url,m.user,m.pass);
				PreparedStatement ps=conn.prepareStatement(queryf);
				){
			
			Scanner sc3 = new Scanner(System.in);
			
			System.out.println("enter email");
			String i3=sc3.next();
			ps.setString(2, i3);
			System.out.println("enter new password:");
			String newpwd=sc3.next();
			ps.setString(1, newpwd);
			ps.executeUpdate();
			System.out.println("Successfully Set New Password:");
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		System.out.println("Enter 1 For Login:");
		System.out.println();
		Scanner sc=new Scanner(System.in);
		int f=sc.nextInt();
		return f;
		
	}

	static final String query7="update tweet2 set status='LOGOUT'";
	@Override
	public int logout() {
		System.out.println();
		System.out.println("LOGOUT:");
		System.out.println();
			
		System.out.println("Eneter yes for Logout");
			Scanner sce=new Scanner(System.in);
	      String status1=sce.next();
	      switch(status1) {
			case "yes":

				try(Connection cons=DriverManager.getConnection(m.db_url,m.user,m.pass);
						PreparedStatement psend=cons.prepareStatement(query7)
				){
					
					psend.executeUpdate();
					System.out.println("Logout Successfully:");
					break;
					
				}
				
				catch(SQLException e) {
					e.printStackTrace();
				}
			case "No":

				try(Connection cons=DriverManager.getConnection(m.db_url,m.user,m.pass);
						PreparedStatement psend=cons.prepareStatement(query8)
				){
					
					psend.executeUpdate();
					System.out.println("Login");
					break;
					
				}
				
				catch(SQLException e) {
					e.printStackTrace();
				}	
				
	}
		return 0;
	}


	@Override
	public int postTweet(ResultSet rs) throws IOException {
		// TODO Auto-generated method stub
		return 0;
	}
			
}

		
