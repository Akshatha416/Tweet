package com.example.model;

public class Login {
	
	private String first_name;
	private String email;
	private String password;
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Login [first_name=" + first_name + ", email=" + email + ", password=" + password + "]";
	}
	public Login() {
		super();
	}
	public Login(String first_name, String email, String password) {
		super();
		this.first_name = first_name;
		this.email = email;
		this.password = password;
	}
	

}
