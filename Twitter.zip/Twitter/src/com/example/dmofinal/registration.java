package com.example.dmofinal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Scanner;
import java.util.*;

public class registration {
	static final String db_url="jdbc:mysql://localhost:3306/assignment2";
	static final String user="root";
	static final String pass="pass@word1";
	static final String query="insert into login(first_name,email,password) values (?,?,?)";
	static final String query1="select * from login where email=? AND password=?";
	static final String query2="update login set password=? where password=?";//reset
	static final String query3="update login set password=? where email=?";
	static final String query4="insert into tweet2(email,first_name,post,date,status) values(?,?,?,?,'Login')";
	//static final String query4="insert into tweet2(email,first_name,post,date,status) select email,first_name from login  AND values(?,?,'Login')";
	static final String query5="select * from tweet2";
	static final String query6=" select * from tweet2 where first_name=?";
	static final String query7="update tweet2 set status='LOGOUT'";
	static final String query8="update tweet2 set status='login'";
	static final String query9="update login set password=? where password=?";
	static final String query10="select first_name from tweet2";
	

	public static void main(String[] args) throws IOException {
		
		
		System.out.println("Welcome to twitter:");
		Scanner sc =new Scanner(System.in);
		String al="yes";
		//if(  al.equals(Logout)) {
				System.out .println("press 2 for --> login \n  1 for --> Registration \n 3 for -->Forgot password");
				int i=sc.nextInt();
				
				
				switch(i) {
				case 1:
					
					System.out.println(" Registeration Page:");
					try(Connection conn=DriverManager.getConnection(db_url,user,pass);
							PreparedStatement ps= conn.prepareStatement(query);)
					{
						Scanner sc2=new Scanner(System.in);
						System.out.println("enter First name:");
						String name=sc2.next();
						System.out.println("enter email:");
						String email1=sc2.next();
						System.out.println("enter the password:");
						String password=sc2.next();
						
						
						
						ps.setString(1, name);
						ps.setString(2, email1);
						ps.setString(3, password);
						
						ps.executeUpdate();
						System.out.println("Registered successfully:");
						
					}
							
					catch(SQLException e) {
						e.printStackTrace();
						
					}

					
					
				
				case 2:
				
					System.out.println("login Page");
					Scanner sc1=new Scanner(System.in);
					System.out.println("Enter email ");
					String email=sc1.next();
					System.out.println("enter password");
					String pwd=sc1.next();
					
				try(Connection conn = DriverManager.getConnection(db_url,user,pass);
						PreparedStatement st= conn.prepareStatement(query1);
							)
				{
					
				
						//System.out.println("valid user");
						st.setString(1,email);
						st.setString(2,pwd);
						
						ResultSet rs=st.executeQuery();
						if(rs.next()) {
							System.out.println("login successfully:");
							System.out.println("-----------");
							System.out.println();
							System.out.println("select 1  for--> view all posts \n  select 2 for--> post a new tweet \n select 3 for-->view his post\n select 4 for-->ResetPassword\n  select 5 for--> VIEW ALL USERS \n");
							
							Scanner scanner=new Scanner(System.in);
							System.out.println("enter the option");
							
							int a=scanner.nextInt();
							switch(a) {
							
							case 1:
								System.out.println("VIEW  ALL POSTS");
								//select * from tweet table
								
								
								try(Connection connt=DriverManager.getConnection(db_url,user,pass);
										Statement stt= conn.createStatement();
										ResultSet rst=stt.executeQuery(query5);){
									
									
									System.out.println("**************************************");
									System.out.println("Details of tweets:");
									System.out.println("**************************************");
									
									while(rst.next()) {
										
										System.out.println( rst.getString("first_name")+"              "+rst.getString("post")+"               "+rst.getString("date")        );
										//sysout (name,email)
										
									i=1;
										
									}
									
									
								}
										
						catch(SQLException e) {
							e.printStackTrace();
						}
								break;
							case 2:
								System.out.println("post a New tweet:");
								
								//try(Connection conp=DriverManager.getConnection(db_url,user,pass);
								      // Statement st=conp.createStatement(q);){
								
								
								
								//insert query
								try(Connection conn2 = DriverManager.getConnection(db_url,user,pass);
										PreparedStatement ps= conn2.prepareStatement(query4);)
								{
									//LocalDate date= LocalDate.now();
									
								
								Scanner scip=new Scanner(System.in);
							    // System.out.println("enter email");
									//String emailp=scip.next();
								String emailp=rs.getString("email");
									//System.out.println("enter  first name:");
									String fnamep=rs.getString("first_name");;
									
									System.out.println("ENTER A POST:");
									//String post=scip.next();
									BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
									//System.out.println("enter text:");
									String post=br.readLine();
									//System.out.println(sc2);
									
//									System.out.println("enter date and time");
//				                      String date=scip.next();	
									LocalDateTime date= LocalDateTime.now();
									//String date=scip.next();
//									System.out.println("enter the status");
//									String status=scip.next();
									
							        ps.setString(1, emailp);
							 		ps.setString(2, fnamep);
									ps.setString(3, post);
									ps.setString(4,date.toString());
									
									
									
									ps.executeUpdate();
									System.out.println("Inserted post successfully:");
								}
										
								catch(SQLException e) {
									e.printStackTrace();
									
								}
								
								break;
							case 3:
								System.out.println("VIEW MY TWEETS");
								//retrieve where select * post, name from tweet where username=?
								
								try(Connection con=DriverManager.getConnection(db_url,user,pass);
										//Statement st6=con.createStatement();
										PreparedStatement ps6=con.prepareStatement(query6);
										)
								{
									//ResultSet rs6=st6.executeQuery(query6);
									//Scanner sc6=new Scanner(System.in);
									//System.out.println("Enter the name to see ur post:");
									//String name6=sc6.next();
									String name6=rs.getString("first_name");
									ps6.setString(1, name6);
									ResultSet rs6=ps6.executeQuery();
									System.out.println("Information about ur Posts");
									//System.out.println("name:"+rs6.getString("first_name"));
									
									while(rs6.next()) {
										//System.out.println("Information about ur Posts");
										//System.out.println("name:"+rs6.getString("first_name"));
										System.out.println("post:"+rs6.getString("post"));
										System.out.println("date:"+rs6.getString("date"));
									}
								}
								catch(SQLException e) {
									e.printStackTrace();
									
								}
								break;
							case 4:
								System.out.println("RESET Password");
								try(Connection connr=DriverManager.getConnection(db_url,user,pass);
										PreparedStatement psr=connr.prepareStatement(query9);
										){
									
									Scanner sc3n = new Scanner(System.in);
									
									System.out.println("Enter New PASSWORD ");
									String newpwd=sc3n.next();
									psr.setString(1, newpwd);
									System.out.println("Enter OLD PASSWORD:");
									String oldpwd=sc3n.next();
									psr.setString(1, newpwd);
									psr.setString(2, oldpwd);
									psr.executeUpdate();
									System.out.println("Successfully Set New Password:");
								}
								catch(SQLException e) 
								{
									e.printStackTrace();
								}
								break;
							case 5:
								System.out.println("VIEW ALL USERS");
								try(Connection conv=DriverManager.getConnection(db_url,user,pass);
										Statement stu=conv.createStatement();
										ResultSet rsu=stu.executeQuery(query10)){
									
									while(rsu.next()) {
										System.out.println(rsu.getString("first_name"));
									}
									
								}
								
								
								
								catch(SQLException e) {e.printStackTrace();}
							}}	

						
						else {
							System.out.println("please enter correct username and password");
						}
						
						
				}
           catch(SQLException e) {
        	   e.printStackTrace();
           }
					
					break;
				
					
				
			
			
			case 3:
				System.out.println("Forgot Password");
				try(Connection conn=DriverManager.getConnection(db_url,user,pass);
						PreparedStatement ps=conn.prepareStatement(query3);
						){
					
					Scanner sc3 = new Scanner(System.in);
					
					System.out.println("enter email");
					String i3=sc3.next();
					ps.setString(2, i3);
					System.out.println("enter new password:");
					String newpwd=sc3.next();
					ps.setString(1, newpwd);
					ps.executeUpdate();
					System.out.println("Successfully Set New Password:");
				}
				catch(SQLException e) 
				{
					e.printStackTrace();
				}
				break;
				
				default:System.out.println("invalid option");
				}
				
			System.out.println();
			System.out.println("LOGOUT:");
			System.out.println();
				
			System.out.println("Eneter yes for Logout");
				Scanner sce=new Scanner(System.in);
		      String status1=sce.next();
		      switch(status1) {
				case "yes":

					try(Connection cons=DriverManager.getConnection(db_url,user,pass);
							PreparedStatement psend=cons.prepareStatement(query7)
					){
						
						psend.executeUpdate();
						System.out.println("Logout Successfully:");
						
						break;
						
					}
					
					catch(SQLException e) {
						e.printStackTrace();
					}
					
				case "No":

					try(Connection cons=DriverManager.getConnection(db_url,user,pass);
							PreparedStatement psend=cons.prepareStatement(query8)
					){
						
						psend.executeUpdate();
						System.out.println("Login");
						break;
						
					}
					
					catch(SQLException e) {
						e.printStackTrace();
					}
                 default:{System.out.println("not able to logout:");}
					
			}
				
				
				
	}

}
