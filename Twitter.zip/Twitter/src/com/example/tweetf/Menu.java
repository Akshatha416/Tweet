package com.example.tweetf;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import com.example.model.Login;
import com.example.twitService.TwitterService;
import com.example.twitService.TwitterServiceImp;

public class Menu {
	
	public static final String db_url="jdbc:mysql://localhost:3306/assignment2";
	public static final String user="root";
	public static final String pass="pass@word1";
	
	
	
	

	public static void main(String[] args) throws IOException {
		
		TwitterService ts=new TwitterServiceImp();
		
System.out.println("WELCOME TO TWITTER");


//While(status.equals('login'))

System.out.println("******************");
System.out.println("Enter 1 for-->Register \n  Enter 2 for --> Login \n Enter 3 for --> Forgot Password");

Scanner sc=new Scanner(System.in);
int i=sc.nextInt();
//while(i==1) {
switch(i) {


case 1:
	      Login l=ts.registration();
	      
	      System.out.println("Now you can LOGIN:");
	
	
case 2:
	//Login
	    // Login l1=
	     ts.login();
	     
	    
	
	 
	
		
//		  System.out.println("Enter 1 for-->Post a Tweet \n Enter 2 for --> View My Tweets \n Enter 3 for--> View All Tweets\n Enter 4 for--> View All Users \n Enter 5 for-->ResetPassword  \n Enter 6 for--> Logout \n");
//		  
//		  System.out.println();
//		  Scanner scc=new Scanner(System.in);
//		  int c=scc.nextInt();
//		  switch(c)
//		  {
//		  case 1:
//			  //POST a TWEET
//			  int ie1=ts.postTweet(l1);
//			 // ts.login();
//			  
//			  if(ie1==1) {ts.viewAllTweets();}
//			  else if (ie1==2) {ts.viewAllUser();}
//			  else if(ie1==3) {ts.logout();}
//			  else if(ie1==4) {ts.resetPassword();}
//			  else {System.out.println("Enter correct choice:");}
//			  i=1;
//		 // break;
//			 
//		  case 2:
//			  //VIEW MY TWEETS
//			  int iv=ts.viewMyTweets(l1);
//			  if(iv==1) {ts.postTweet(l1);}
//			  else if(iv==2) {ts.viewAllTweets();}
//			  else if(iv==3) {ts.viewAllUser();}
//			  else if(iv==4) {ts.resetPassword();}
//			  else if(iv==5) { ts.logout();}
//			  else System.out.println("enter correct choice");
//			  //ts.login();
//			  //break;
//		  case 3:
//			  //VIEW All TWEETS
//			  
//			 int a=ts.viewAllTweets();
//			 ts.login();
//			 
//			 if(a==1) { ts.login();}
//			 
//			 else if(a==2) {ts.resetPassword();}
//			 else if(a==3) {  ts.logout();}
//			 else if(a==4) {ts.viewAllUser();}
//			else System.out.println("enter correct choice");
//			  i =1;
//			 // break;
//			 
//			  
//		  case 4:
//			  
//			  int b=ts.viewAllUser();
//			  if(b==1) { ts.resetPassword();}
//				 
//				 else if(b==2)   ts.logout();
//				 else if(b==3) ts.postTweet(l1);
//				 else if(b==4) ts.viewAllTweets();
//				 else System.out.println("enter correct choice");
//			  //ts.login();
//			  break;
//		  case 5:
//			 int cd= ts.resetPassword();
//			 if(cd==1) { Login l4=ts.login();
//			 System.out.println("Post");
//                ts.postTweet(l1);}
//			 else if (cd==2) {ts.postTweet(l1);}
//			 else System.out.println("enter correct choice");
//			 
//			 // break;
//		  case 6:
//			int i2 = ts.logout(); 
//			  //if(i2==0) {i=0;}
//			//  break;
//			  //else System.out.println("enter correct choice");
//			  
//			  
//	  }
	break;
case 3:
	
	//Forgot Password
	int g=ts.forgotPassword();
	
	if(g==1) {ts.login();
	}
	 else System.out.println("enter correct choice");
	
}




	}

}
