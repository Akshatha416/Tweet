package com.example.tweetf;

import java.sql.SQLException;

public class Registration {
	
	public void registration() {

	//try(con=){}
	//catch(SQLException e) {e.printStackTrace();}
}
}