package com.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Scanner;

import org.junit.jupiter.api.Test;

import com.example.model.Login;
import com.example.twitService.TwitterService;
import com.example.twitService.TwitterServiceImp;

class Tweettest {

//	@Test
//	void test() {
//		fail("Not yet implemented");
//	}
	@Test
	public void testingregister() {
		assertEquals("here is the test",hello());
	}
	
	public String hello() {
		String h="here is the test";
		return h;
	}
	
	 TwitterService t=new TwitterServiceImp();
	 private TwitterService t1;
	 @Test
	public void testregister() {
		 Login l=new Login("hhh","hhhh@123","r@1234");
		 
		 Login l1=t.registration();
		 Scanner sc=new Scanner(System.in);
		 String first_name=sc.next();
		 String email= sc.next();
		 String password=sc.next();
		 
		 assertEquals(first_name, "hhh");
		
		
	}
}
