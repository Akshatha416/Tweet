package com.example.finaltweet;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.Scanner;

import org.junit.jupiter.api.Test;

//import com.example.model.Login;

class TweetTest {

//	@Test
//	void test() {
//		fail("Not yet implemented");
//	}
	
	
	@Test
	public void testingregister() {
		assertEquals("here is the test",hello());
	}
	
	public String hello() {
		String h="here is the test";
		return h;
	}
	
	Register r=new Register();
	
	@Test
	public void testregister() {
		 
		 
		 r.registration();
		 Scanner sc=new Scanner(System.in);
		 String first_name=sc.next();
		 String email= sc.next();
		 String password=sc.next();
		 
		 assertEquals(first_name, "arav");
		 assertEquals(email, "arav@gmail.com");
		 assertEquals(password, "arav@123");
		 
	 }
	Logint l=new Logint();
	@Test
	public void testlogin() throws IOException {
		l.logint();
	 Scanner sc=new Scanner(System.in);
	 
	 String email= sc.next();
	 String password=sc.next();
	 
	 //assertEquals(first_name, "arav");
	 assertEquals(email, "arav@gmail.com");
	 assertEquals(password, "arav@123");
	 
	 }
	Forgotpwd fp=new Forgotpwd();
	@Test
	public void testforgotpwd() {
		Scanner sc=new Scanner(System.in);
		String email=sc.next();
		//String newpwd=sc.next();
		assertEquals(email,"arav@gmail.com");
	}

}
