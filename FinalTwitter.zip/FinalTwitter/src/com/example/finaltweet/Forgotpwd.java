package com.example.finaltweet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Forgotpwd {
	
	static final String db_url="jdbc:mysql://localhost:3306/assignment2";
	static final String user="root";
	static final String pass="pass@word1";
	static final String query3="update login set password=? where email=?";
	
	
public static void forgotpwd() {
	System.out.println("Forgot Password");
	try(Connection conn=DriverManager.getConnection(db_url,user,pass);
			PreparedStatement ps=conn.prepareStatement(query3);
			){
		
		Scanner sc3 = new Scanner(System.in);
		
		System.out.println("enter email");
		String i3=sc3.next();
		ps.setString(2, i3);
		System.out.println("enter new password:");
		String newpwd=sc3.next();
		ps.setString(1, newpwd);
		ps.executeUpdate();
		System.out.println("Successfully Set New Password:");
	}
	catch(SQLException e) 
	{
		e.printStackTrace();
	}

}
}
