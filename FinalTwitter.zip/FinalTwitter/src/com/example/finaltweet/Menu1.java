package com.example.finaltweet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;



public class Menu1 {
	

	public static void main(String[] args) throws IOException {
		
		Register r =new Register();
		Logint l=new Logint();
		Forgotpwd fp=new Forgotpwd();
		Logout lo=new Logout();

		System.out.println("WELCOME TO FOOD APP:");
		

		 System.out.println("Enter Choice:");
     System.out.println("select 1 for--> Registration \n select 2 for --> Login \n select 3 for--> Forgot PassWord\n");
     Scanner sc= new Scanner(System.in);
    
     int i=sc.nextInt();
     switch(i)
     {
     case 1:
                 r.registration();
		 System.out.println("Now you can login :");
      case 2:
    	  l.logint();
    	  break;
      case 3:
    	  
    	  fp.forgotpwd();
    	  break;
      default:
		  
	      {System.out.println("Enter correct Choice:");} }
     
     lo.logout();
    	  
    	  
      }
     }
	
    	  

	


