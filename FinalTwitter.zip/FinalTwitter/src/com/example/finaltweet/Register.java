package com.example.finaltweet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Register {
	static final String db_url="jdbc:mysql://localhost:3306/assignment2";
	static final String user="root";
	static final String pass="pass@word1";
	
	//Menu1 m=new Menu1();
	static final String query1="insert into login(first_name,email,password) values (?,?,?)";

	public static void registration() {
		System.out.println(" Registeration Page:");
		try(Connection conn=DriverManager.getConnection(db_url,user,pass);
				PreparedStatement ps= conn.prepareStatement(query1);)
		{
			Scanner sc2=new Scanner(System.in);
			System.out.println("enter First name:");
			String name=sc2.next();
			System.out.println("enter email:");
			String email1=sc2.next();
			System.out.println("enter the password:");
			String password=sc2.next();
			ps.setString(1, name);
			ps.setString(2, email1);
			ps.setString(3, password);
			ps.executeUpdate();
			System.out.println("Registered successfully:");
		}
				
		catch(SQLException e) {
			e.printStackTrace();
			
		}

		
	}
}
