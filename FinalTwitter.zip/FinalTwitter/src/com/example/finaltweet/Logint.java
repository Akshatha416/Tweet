package com.example.finaltweet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.Scanner;

public class Logint {
	static final String db_url="jdbc:mysql://localhost:3306/assignment2";
	static final String user="root";
	static final String pass="pass@word1";
	static final String query1="select * from login where email=? AND password=?";
	static final String query4="insert into tweet2(email,first_name,post,date,status) values(?,?,?,?,'Login')";
	static final String query5="select * from tweet2";
	static final String query6=" select * from tweet2 where first_name=?";
	static final String query9="update login set password=? where password=?";
	static final String query10="select first_name from tweet2";
	
	public static void logint() throws IOException {

		System.out.println("login Page");
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter email ");
		String email=sc1.next();
		System.out.println("enter password");
		String pwd=sc1.next();
		
	try(Connection conn = DriverManager.getConnection(db_url,user,pass);
			PreparedStatement st= conn.prepareStatement(query1);
				)
	{
		
	
			
			st.setString(1,email);
			st.setString(2,pwd);
			
			ResultSet rs=st.executeQuery();
			if(rs.next()) {
				System.out.println("login successfully:");
				System.out.println("------------------");
				System.out.println();
				System.out.println("select 1  for--> view all posts \n  select 2 for--> post a new tweet \n select 3 for-->view his post\n select 4 for-->ResetPassword\n  select 5 for--> VIEW ALL USERS \n");
				
				Scanner scanner=new Scanner(System.in);
				System.out.println("enter the option");
				
				int a=scanner.nextInt();
				switch(a) {
				
				case 1:
					System.out.println("VIEW  ALL POSTS");
					//select * from tweet table
					
					
					try(Connection connt=DriverManager.getConnection(db_url,user,pass);
							Statement stt= conn.createStatement();
							ResultSet rst=stt.executeQuery(query5);){
					
						System.out.println("         Details of tweets :          ");
						System.out.println("***********************************************************************************************************");
						System.out.println(       "  Name:                                      Post                                       Date ");
						System.out.println("**********************************************************************************************************");
						while(rst.next()) {
							
							System.out.println(rst.getString("first_name")+"               "+rst.getString("post")+"               "+rst.getString("date")      );
							//sysout (name,email)
							
						
							
						}
						
						
					}
							
			catch(SQLException e) {
				e.printStackTrace();
			}
					break;
				case 2:
					System.out.println("post a New tweet:");
					
					
					try(Connection conn2 = DriverManager.getConnection(db_url,user,pass);
							PreparedStatement ps= conn2.prepareStatement(query4);)
					{
						
						
					
					Scanner scip=new Scanner(System.in);
				    
					     String emailp=rs.getString("email");
						
						String fnamep=rs.getString("first_name");;
						
						System.out.println("ENTER A POST:");
						
						BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
						
						
						String post= br.readLine();
						
						LocalDateTime date= LocalDateTime.now();
						
						 ps.setString(1, emailp);
				 		ps.setString(2, fnamep);
						ps.setString(3, post);
						ps.setString(4,date.toString());
						
						
						
						ps.executeUpdate();
						System.out.println("Inserted post successfully:");
					}
							
					catch(SQLException e) {
						e.printStackTrace();
						
					}
					break;
				case 3:
					System.out.println("VIEW MY TWEETS");
					
					
					try(Connection con=DriverManager.getConnection(db_url,user,pass);
							//Statement st6=con.createStatement();
							PreparedStatement ps6=con.prepareStatement(query6);
							)
					{
						//ResultSet rs6=st6.executeQuery(query6);
						//Scanner sc6=new Scanner(System.in);
						//System.out.println("Enter the name to see ur post:");
						//String name6=sc6.next();
						String name6=rs.getString("first_name");
						ps6.setString(1, name6);
						ResultSet rs6=ps6.executeQuery();
						System.out.println("**************************************");
						System.out.println("  Information about ur Posts ");
						System.out.println("***************************************");
						System.out.println("post                  DateAndTime");
	
						//System.out.println("name:"+rs6.getString("first_name"));
						
						while(rs6.next()) {
							//System.out.println("Information about ur Posts");
							//System.out.println("name:"+rs6.getString("first_name"));
//							System.out.println("post:"+rs6.getString("post"));
//							System.out.println("date:"+rs6.getString("date"));
							System.out.println(rs6.getString("post")+"               "+rs6.getString("date"));
						}
					}
					catch(SQLException e) {
						e.printStackTrace();
						
					}
					break;
				case 4:
					System.out.println("RESET Password");
					try(Connection connr=DriverManager.getConnection(db_url,user,pass);
							PreparedStatement psr=connr.prepareStatement(query9);
							){
						
						Scanner sc3n = new Scanner(System.in);
						
						System.out.println("Enter New PASSWORD ");
						String newpwd=sc3n.next();
						psr.setString(1, newpwd);
						System.out.println("For Confirmation");
						System.out.println("Enter  your OLD PASSWORD:");
						String oldpwd=sc3n.next();
						psr.setString(1, newpwd);
						psr.setString(2, oldpwd);
						psr.executeUpdate();
						System.out.println("Successfully Set New Password:");
					}
					catch(SQLException e) 
					{
						e.printStackTrace();
					}
					break;
				case 5:
					
					System.out.println("**********************************");
					System.out.println("      VIEW ALL USERS               ");
					System.out.println("**********************************");
					System.out.println("    Name              Email_Id    ");
					
					try(Connection conv=DriverManager.getConnection(db_url,user,pass);
							Statement stu=conv.createStatement();
							ResultSet rsu=stu.executeQuery(query10)){
						
						while(rsu.next()) {
							System.out.println(rsu.getString("first_name")+"         "+rsu.getString("email"));
						}
						
					}
					
					
					
					catch(SQLException e) {e.printStackTrace();}
					
					
				}}	

			
			else {
				System.out.println("please enter correct username and password");
			}
			
			
	}
catch(SQLException e) {
   e.printStackTrace();
}
		
	
	
		
	}

}
