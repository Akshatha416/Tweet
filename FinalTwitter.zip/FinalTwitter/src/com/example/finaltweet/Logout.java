package com.example.finaltweet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Logout {
	
	static final String db_url="jdbc:mysql://localhost:3306/assignment2";
	static final String user="root";
	static final String pass="pass@word1";
	static final String query7="update tweet2 set status='LOGOUT'";
	static final String query8="update tweet2 set status='login'";
	
	
	

	public static void logout() {
		System.out.println();
		 System.out.println("LOGOUT:");
		 System.out.println();
						
					System.out.println("Eneter yes for Logout");
						Scanner sce=new Scanner(System.in);
				      String status1=sce.next();
				      switch(status1) {
						case "yes":
		
							try(Connection cons=DriverManager.getConnection(db_url,user,pass);
									PreparedStatement psend=cons.prepareStatement(query7)
							){
								
								psend.executeUpdate();
								System.out.println("Logout Successfully:");
								break;
								
							}
							
							catch(SQLException e) {
								e.printStackTrace();
							}
						case "No":
		
							try(Connection cons=DriverManager.getConnection(db_url,user,pass);
									PreparedStatement psend=cons.prepareStatement(query8)
							){
								
								psend.executeUpdate();
								System.out.println("Login");
								break;
								
							}
							
							catch(SQLException e) {
								e.printStackTrace();
							}
		               default:{System.out.println("not able to logout:");}
						
					}
		
	}
}
